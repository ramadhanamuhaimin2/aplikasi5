<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pemesanan extends CI_Controller
{
    public function index()
    {
    }

    /**
     * Tampil Form Tambah
     */
    public function create()
    {
    }

    /**
     * Insert ke database
     */
    public function insert()
    {
    }

    /**
     * Tampil fForm Edit
     */
    public function edit()
    {
    }

    /**
     * Update data
     */
    public function update()
    {
    }

    /**
     * Delete data
     */
    public function delete()
    {
    }
}
